function enter(pi) {
	pi.inFreeMarket();
}