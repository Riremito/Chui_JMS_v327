function enter(pi) {
    pi.playPortalSE();
    pi.warp(211042300, "ps00");
    return true;
}