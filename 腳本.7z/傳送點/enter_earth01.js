function enter(pi) {
    pi.warp(120000101,"earth01");
}