/* Dawnveil
    Ellinel Fairy Academy
    Made by Daenerys
*/
function enter(pi) {
    pi.playPortalSE();
    pi.warp(101070000,0);
    return true;
}