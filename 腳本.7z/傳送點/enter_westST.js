function enter(pi) {
    pi.warp(940000100,0);
}