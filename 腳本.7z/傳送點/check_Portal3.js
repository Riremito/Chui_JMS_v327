function enter(pi) {
    if (pi.getQuestStatus(31175) == 1 || pi.getQuestStatus(31175) == 2) pi.warp(272000400,1);
}