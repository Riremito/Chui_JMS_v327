function enter(pi) {
    pi.openNpc(2184000);
    return true;
}