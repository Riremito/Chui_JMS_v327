function enter(pi) {
	pi.playPortalSE();
    pi.warp(211060620, 2); // Lion King's Castle: Tall Castle Walls 1
	return true;
}