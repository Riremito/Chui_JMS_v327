function enter(pi) {
    pi.warp(400000000,0);
}