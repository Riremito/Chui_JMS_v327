function enter(pi) {
    pi.warp(pi.getMapId() - 2,0);
}