function enter(pi) {
    if (pi.getQuestStatus(59008) === 1) {
        pi.warp(866108000, 2);
    }
}