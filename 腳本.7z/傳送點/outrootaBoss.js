function enter(pi) {
        pi.openNpc(1064024);
        pi.playPortalSE();
}