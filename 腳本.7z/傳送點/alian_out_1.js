function enter(pi) {
    pi.warp(600010200, 0);
}