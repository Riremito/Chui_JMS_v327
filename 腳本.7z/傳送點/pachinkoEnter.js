function enter(pi) {
    pi.playerMessage(5, "This portal is not available at the moment.");
}