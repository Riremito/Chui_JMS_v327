function enter(pi) {
    if (pi.getMapId() != 130030006) {
        pi.summonMsg(11);
    }
}