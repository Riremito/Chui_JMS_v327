function enter(pi) {
    pi.warp(684000000,0);
}