function enter(pi) {
    if (java.lang.Math.random() < 0.1) {
	pi.warp(930000300,"16st");
    } else {
	pi.warp(930000300, "01st");
    }
}