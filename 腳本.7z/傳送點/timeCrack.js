function enter(pi) {
    pi.playPortalSE();
    pi.warp(272000100);
    return true;
}