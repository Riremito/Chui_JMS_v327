function enter(pi) {
    pi.playPortalSE();
    pi.warp(400030610);
    return true;
}