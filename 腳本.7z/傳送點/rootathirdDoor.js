function enter(pi) {
    pi.openNpc(1064014);
    return true;
}