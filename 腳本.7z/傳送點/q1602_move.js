function enter(pi) {
    //pi.getMap(931050402).respawn(true);
    pi.resetMap(931050402);
    pi.warp(931050402, "out00");
    return true;
}