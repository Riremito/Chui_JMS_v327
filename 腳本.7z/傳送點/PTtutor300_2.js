function enter(pi) {
    pi.openNpc(1402001);
    return true;
}