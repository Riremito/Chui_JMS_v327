/* Red
    Explorer tut
    Made by Daenerys
*/
function enter(pi) {
    if (pi.getQuestStatus(32207)==2){
    pi.ShowWZEffect("Effect/OnUserEff.img/guideEffect/cygnusTutorial/7");
	return true;
   }
 }
