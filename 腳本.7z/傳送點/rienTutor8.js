function enter(pi) {
    pi.playPortalSE();
    pi.warp(140010000, 2);
}