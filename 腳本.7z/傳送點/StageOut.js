function enter(pi) {
    pi.openNpc(9330192,2);
    return true;
}