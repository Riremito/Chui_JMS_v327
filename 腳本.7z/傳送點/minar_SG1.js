function enter(pi) {
    pi.playPortalSE();
    pi.warp(240010000,1);
}