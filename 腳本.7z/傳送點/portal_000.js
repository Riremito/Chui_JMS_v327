//importPackage(Packages.tools.packet);
function enter(pi) {
    pi.sendDirectionStatus(3, 0, false);
    //pi.dispose();
}