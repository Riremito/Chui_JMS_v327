function enter(pi) {
	pi.playPortalSE();
    pi.warp(910510500, 1);
	return true;
}