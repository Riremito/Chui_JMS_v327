function enter(pi) {
    pi.warp(552000030);
}