function enter(pi) {
    pi.openNpc(2159008);
	return true;
}