function enter(pi) {
    pi.warp(220060000,5);
}