function enter(pi) {
    if (pi.getQuestStatus(59002) === 1) {
        pi.warp(866102000, 1);
    }
}