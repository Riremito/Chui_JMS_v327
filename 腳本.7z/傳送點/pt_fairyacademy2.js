/* Dawnveil
    Ellinel Fairy Academy
    Made by Daenerys
*/
function enter(pi) {
    pi.openNpc(1500025);
}  