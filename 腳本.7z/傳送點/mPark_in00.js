function enter(pi) {
    pi.openNpc(9071004);
}