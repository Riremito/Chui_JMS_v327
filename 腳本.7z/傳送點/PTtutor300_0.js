function enter(pi) {
    pi.openNpc(1402001, "PTtutor300_1");
    return true;
}