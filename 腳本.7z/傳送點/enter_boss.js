function enter(pi) {
    pi.warp(610040400);
}