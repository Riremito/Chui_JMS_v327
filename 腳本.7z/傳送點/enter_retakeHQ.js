/* Cygnus revamp
	Heliseum Reclamation HQ (Heliseum)
    Made by Daenerys
*/

function enter(pi) {
    pi.playPortalSE();
    pi.warp(401000000,3);
    return true;
}