/* Dawnveil
	Portal in Tynerum
    Made by Daenerys
*/
function enter(pi) {
    pi.openNpc(9390101);
}  