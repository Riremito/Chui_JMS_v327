function enter(pi) {
    pi.openNpc(2159001);
	return true;
}