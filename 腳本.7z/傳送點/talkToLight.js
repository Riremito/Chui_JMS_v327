/* RED 1st impact
    Explorer tut
    Made by Daenerys
*/
function enter(pi) {
	pi.openNpc(10310);
}
