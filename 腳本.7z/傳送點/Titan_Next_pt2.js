function enter(pi) {
    var target = pi.getMapId() + 100;
    pi.warp(target, "ps00");
}