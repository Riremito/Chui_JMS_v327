function enter(pi) {
    pi.openNpc("PTtutor400_0");
    return true;
}