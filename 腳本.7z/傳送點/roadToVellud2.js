/* Dawnveil
	Portal in Tynerum
    Made by Daenerys
*/
function enter(pi) {
    pi.playPortalSE();
    pi.warp(863010000,1);
    return true;
}