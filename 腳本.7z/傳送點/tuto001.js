function enter(pi) {
    pi.getDirectionInfoTest(3, 0);
    pi.openNpc(1106000, "tuto001");
    return true;
}