function enter(pi) {
	pi.warp(910350200,0);
}