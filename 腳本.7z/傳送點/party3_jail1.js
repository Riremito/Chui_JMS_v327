function enter(pi) {
    pi.warp(920010910,0);
}