function enter(pi) {
    pi.getPlayer().message(5, "YOU SHALL NOT PASS.");
    return false;
}
