function enter(pi) {
    pi.warpParty(pi.getMapId() + 100, "st00");
}