function enter(pi) {
    pi.openNpc(2183005);
}