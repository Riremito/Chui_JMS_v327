function enter(pi) {
	pi.openNpc(2103013);
	return true;
}