function enter(pi) {
    pi.warp(940000060,0);
}