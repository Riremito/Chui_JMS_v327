function enter(pi) {
	pi.playPortalSE();
    pi.warp(401051100, 0);
	return true;
}