/* Cygnus revamp
	Portal to Sleepywood
    Made by Daenerys
*/

function enter(pi) {
    pi.playPortalSE();
    pi.warp(105000000,0);
    return true;
}