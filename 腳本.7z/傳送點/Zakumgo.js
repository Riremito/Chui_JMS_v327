/*
    Zakum Entrance
*/

function enter(pi) {
    pi.clearSavedLocation("BPReturn");
    pi.warp(211042300, 2);
}