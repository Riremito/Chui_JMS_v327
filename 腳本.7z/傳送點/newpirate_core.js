function enter(pi) {
    if (pi.getQuestStatus(53253)==1) pi.openNpc(2111007);
    else pi.warp(240000000);
}