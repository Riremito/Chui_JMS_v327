function enter(pi) {
    pi.playPortalSE();
    pi.warp(926130000,2);
}