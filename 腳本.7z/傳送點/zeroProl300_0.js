/* RED 1st impact
    Zero tut
    Made by Daenerys
*/
function enter(pi) {
   pi.warp(321000400,0);
}
