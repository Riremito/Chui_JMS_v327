function enter(pi) {
    pi.showInstruction("Press #e#b[Alt]#k#n to\r\\ JUMP.", 100, 5);
}