/*
 Author: Pungin
 */

function enter(pi) {
    pi.warp(310010000, 0);
}


