function enter(pi) {
	pi.playPortalSE();
	pi.warp(271040000, 1);
	return true;
}