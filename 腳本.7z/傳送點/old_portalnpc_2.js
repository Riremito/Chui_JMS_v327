function enter(pi) {
    pi.warp(100020000, "west00");
}