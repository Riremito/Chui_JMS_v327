/* Cygnus revamp
	Downtown Black Market(Heliseum)
    Made by Daenerys
*/

function enter(pi) {
    pi.playPortalSE();
    pi.warp(401040000,4);
    return true;
}