function enter(pi) {
    pi.topMsg("現在還無法移動。");
}