function enter(pi) {
    pi.warp(921110100,0);
}