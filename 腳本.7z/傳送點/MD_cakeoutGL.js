function enter(pi) {
    pi.warp(683000000,0);
}