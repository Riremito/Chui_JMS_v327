function enter(pi) {
    pi.openNpc(1402001, "PTtutor200_1");
    return true;
}