function enter(pi) {
    pi.playPortalSE();
    pi.warp(240010501, "out00");
    return true;
}