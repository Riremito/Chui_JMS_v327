function enter(pi) {
    pi.openNpc("hontale_pass");
}