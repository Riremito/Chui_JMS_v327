function enter(pi) {
    if (pi.getQuestStatus(53244)==1 || pi.getQuestStatus(53244)==2) pi.warp(552000070);
}