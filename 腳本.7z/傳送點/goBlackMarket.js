/* Cygnus revamp
	Downtown Entrance(Heliseum)
    Made by Daenerys
*/

function enter(pi) {
    pi.playPortalSE();
    pi.warp(401040001,1);
    return true;
}