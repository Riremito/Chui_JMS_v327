function enter(pi) {
    pi.openNpc("kenjiTutoDirection");
}