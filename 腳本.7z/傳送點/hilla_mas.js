/* Dawnveil
	Portal in Tynerum
    Made by Daenerys
*/
function enter(pi) {
    pi.playPortalSE();
    pi.warp(863100104,"west00");
    return true;
}