/* Cygnus revamp
	Tyrant's Throne(Heliseum)
    Made by Daenerys
*/

function enter(pi) {
    pi.playPortalSE();
    pi.warp(401060100,1);
    return true;
}