function enter(pi) {
    pi.warp(104020120, 0);
}