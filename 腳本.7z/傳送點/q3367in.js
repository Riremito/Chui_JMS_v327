function enter(pi) {
    pi.warp(926130102,0);
    pi.playPortalSE();
}