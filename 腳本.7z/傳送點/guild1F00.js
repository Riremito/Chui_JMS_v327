/*
Return from Sharen III's Grave - Guild Quest

@Author Lerk
*/

function enter(pi) {
    pi.warp(990000600, 1);
}