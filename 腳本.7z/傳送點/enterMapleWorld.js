/* RED 1st impact
    Zero tut
    Made by Daenerys
*/
function enter(pi) {
   pi.openNpc(2400025);
}
