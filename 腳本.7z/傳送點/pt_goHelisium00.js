/* Cygnus revamp
	Heliseum Transitional Dimension Door(Heliseum)
    Made by Daenerys
*/

function enter(pi) {
    pi.playPortalSE();
    pi.warp(401000002,1);
    return true;
}