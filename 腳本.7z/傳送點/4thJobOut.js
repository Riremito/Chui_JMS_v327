function enter(pi) {
    pi.openNpc(9010000, "4thJobAdvanceOut");
    return false;
}
