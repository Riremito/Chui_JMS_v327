function enter(pi) {
    pi.warp(223000000,0);
}