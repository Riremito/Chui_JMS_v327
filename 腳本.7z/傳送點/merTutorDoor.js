function enter(pi) {
    if (pi.isQuestFinished(24004)) {
        return;
    }
    pi.warp(910150002,2);
}