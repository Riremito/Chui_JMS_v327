function enter(pi) {
}