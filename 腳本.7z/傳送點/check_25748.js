function enter(pi) {
    pi.playPortalSE();
    pi.warp(400010510);
    return true;
}