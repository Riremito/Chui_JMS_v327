function enter(pi) {
    pi.warp(223010000,0);
}