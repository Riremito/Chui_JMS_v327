function enter(pi) {
    pi.playPortalSE();
    pi.warp(400030000);
    return true;
}