function enter(pi) {
    pi.warp(920010920,0);
}