function enter(pi) {
    pi.playPortalSE();
    pi.saveLocation("MULUNG_TC")
    pi.warp(749050400, "out00");
}