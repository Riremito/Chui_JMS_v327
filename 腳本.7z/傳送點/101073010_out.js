/* Dawnveil
	Ellinel Fairy Academy
    Made by Daenerys
*/
function enter(pi) {
    pi.playPortalSE();
    pi.warp(101073000,3);
    return true;
}