function enter(pi) {
	pi.openNpc(1052007);
	return true;
}