function enter(pi) {
    if (pi.getMap().getAllMonstersThreadsafe().size() < 1)
    {
        pi.warp(915010200,1);
    }
}