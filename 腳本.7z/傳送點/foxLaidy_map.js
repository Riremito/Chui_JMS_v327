function enter(pi) {
	pi.warp(222010200, "east00");
	return true;
}
