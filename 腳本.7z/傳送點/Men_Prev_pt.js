function enter(pi) {
    pi.warp(pi.getMapId() - 100, "next00");
}