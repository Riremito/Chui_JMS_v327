function enter(pi) {
    pi.openNpc(2081005);
}