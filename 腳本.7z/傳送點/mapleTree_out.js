function enter(pi) {
	pi.openNpc(9270035);
	return true;
}