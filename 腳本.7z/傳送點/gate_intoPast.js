function enter(pi) {
    pi.playPortalSE();
    pi.warp(270010000, 1);
    return true;
}