/* RED 1st impact
    Zero tut
    Made by Daenerys
*/
function enter(pi) {
   pi.warp(320000100,1);
}
