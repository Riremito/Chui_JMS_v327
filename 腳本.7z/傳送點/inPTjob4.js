function enter(pi) {
    if (pi.getQuestStatus(25121)==1 || pi.getQuestStatus(29970)==2 || pi.getQuestStatus(25121)==2) {
        pi.warp(915010201,"out00");
    } 
}